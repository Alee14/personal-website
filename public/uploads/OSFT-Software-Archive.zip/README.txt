Title:
Philip Adams Software Archive
by: Philip Adams

Topics: shiftos, histacom, dark os, htmlive, osfirsttimer, artpad, 12padams

Description:

This is the software collection of Philip Adams' software (OSFirstTimer, 12padams, AstralPhaser, ShiftOS).

These software require .NET Framework 3.5, 4.0 and/or 4.5 to function.

Warning some of the software in this pack has a jumpscare, and if you have epilepsy please be cautious with this pack.

Also be sure to disable the antivirus if you want to try out Mitosis

This pack includes the following:
Artpad (from ShiftOS)
Amazing Maze (Requires a flash player)
Averager
Board Game Maker
Bouncing Ball Physics 0.3
Chebinect
Chrono Machine 0.9.3
Colors
Dark OS Studio
Digging
Draw
Dropper
Explore 0.3.7
File Viewer (Warning jumpscare)
File Wars
"funny nana and grampa sounds version 1.1"
Guess The Number
Histacom 1.8.5 (Epliespy warning)
HTMLive
IIR (Interactive Infinite Road)
Infinijump 0.1
Mitosis 0.6
OSFirstTimer Blue Screen (Warning jumpscare)
Paper Math 2D
Philip's Mario Game
Phone Simulator 0.4
Picture Generator
Pixel Physics 0.3
Road Simulator 0.4
RPG Map Maker
ShiftOS 0.0.8 (Epliespy warning)
Theme Test
Thoto 0.3
Time Machine 0.4
Typewriter
Vending Machine
Visual Sound (Ear blast warning lower the volume)
Zeon OS 0.2

If some of the software does not work, please contact me at andrew@alee14.me.

I got permission from the original creator to post this.
